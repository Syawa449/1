package com.epam.izh.rd.online;

public class JavaBasics {
    public static void main(String[] args) {

    }
}
