package com.epam.izh.rd.online.service;

public class Seller {
}
