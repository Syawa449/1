package com.epam.izh.rd.online.service;

public class Applicant {
}
